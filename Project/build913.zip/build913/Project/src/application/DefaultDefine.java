package application;

public class DefaultDefine {
	public static String iconPath = "D:\\Buffer\\Chattincrypted\\usericon\\";
	public static String FilePath = "D:\\Buffer\\Chattincrypted\\receive\\";
	public static String socketIP = "192.168.80.105";
	public static int socketPart = 5003;
}
