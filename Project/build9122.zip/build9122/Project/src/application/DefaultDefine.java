package application;

public class DefaultDefine {
	public static String iconPath = "D:\\Buffer\\Chattincrypted\\";
}
