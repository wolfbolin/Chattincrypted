package application;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.regex.Pattern;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class MainWindow {
	public static Stage windowStage;
	public String userID;
	private static String chatuser;
	SimpleDateFormat dateFormat = new SimpleDateFormat("  yyyy/MM/dd HH:mm:ss\n");

	@FXML
	private ImageView minimize;

	@FXML
	private Button sendPic;

	@FXML
	private TextArea inputArea;

	@FXML
	private ImageView friendicon;

	@FXML
	private ImageView backbutton;

	@FXML
	private ImageView messageShowicon;

	@FXML
	private Button sendMessage;

	@FXML
	private ImageView shutdownShow;

	@FXML
	private ImageView avatar;

	@FXML
	private HBox title;

	@FXML
	private HBox tools;

	@FXML
	private Button sendFile;

	@FXML
	private TextField search;

	@FXML
	private ImageView deletefriend;

	@FXML
	private TextArea messageArea;

	@FXML
	private ImageView friendinfo;

	@FXML
	private ScrollPane friendList;

	@FXML
	private Button sendVoice;

	@FXML
	private ImageView minimizeShow;

	@FXML
	private ImageView shutdown;

	@FXML
	private ImageView friendShowicon;

	@FXML
	private ImageView messageicon;

	@FXML
	private Label friendname;

	@FXML
	void minimize_onMousePressed(MouseEvent event) {
		System.out.println("minimize");
		MainWindow.windowStage.setIconified(true);
	}

	@FXML
	void minimize_onMouseEntered(MouseEvent event) {
		minimize.setVisible(false);
	}

	@FXML
	void minimize_onMouseExited(MouseEvent event) {
		minimize.setVisible(true);
	}

	@FXML
	void shutdown_onMousePressed(MouseEvent event) {
		System.out.println("shutdown");
		MainWindow.windowStage.close();
		System.exit(0);
	}

	@FXML
	void shutdown_onMouseExited(MouseEvent event) {
		shutdown.setVisible(true);
	}

	@FXML
	void shutdown_onMouseEntered(MouseEvent event) {
		shutdown.setVisible(false);
	}
	
	@FXML
    void avatar_onMousePressed(MouseEvent event) {
		System.out.println("refreash list");
		updateFriendList(true);
		VBox viewList = new VBox();
		for (int i = 0; i < Main.friendlist.size(); i++) {
			FriendInfo friend = Main.friendlist.get(i);
			System.out.println("add friend " + friend.getNickname());
			HBox node = friend.toHBox();
			node.setOnMouseClicked(e -> {
				openWindow(e, friend.getUsername(), friend.getNickname(), friendname, title, messageArea, tools,
						inputArea);
			});
			viewList.getChildren().add(node);
		}
		friendList.setContent(viewList);
    }

	@FXML
	void search_onKeyTyped(KeyEvent event) {
		System.out.println("Text=" + search.getText());
		System.out.println("Event=" + event.getCharacter());

		String wordornum = "[A-Za-z0-9]*";
		String searchword = "";
		if (Pattern.matches(wordornum, event.getCharacter())) {
			searchword += search.getText() + event.getCharacter();
		} else {
			searchword += search.getText();
		}

		if (!Pattern.matches(wordornum, searchword)) {
			search.setText("");
		}
		
		String searchname = searchword;
		if (!searchword.isEmpty()) {
			searchword = wordornum + searchword + wordornum;
		}

		VBox viewList = new VBox();
		for (int i = 0; i < Main.friendlist.size(); i++) {
			FriendInfo friend = Main.friendlist.get(i);
			if (searchword.isEmpty() || Pattern.matches(searchword, friend.getUsername())
					|| Pattern.matches(searchword, friend.getNickname())) {
				System.out.println("add friend " + friend.getNickname());
				HBox node = friend.toHBox();
				node.setOnMouseClicked(e -> {
					openWindow(e, friend.getUsername(), friend.getNickname(), friendname, title, messageArea, tools,
							inputArea);
				});
				viewList.getChildren().add(node);
			}
		}
		if (!searchname.isEmpty()) {
			String searchName = searchname;
			HBox node = addiconHBox();
			node.setOnMouseClicked(e -> {
				Main.messageManner.clear();
				Main.messageManner.setAction("get-user-info");
				Main.messageManner.setUsername(searchName);
				Main.messageManner.sendMessage();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if (Main.messageManner.status()) {
					InfoWindow infoWindow = new InfoWindow();
					infoWindow.userName = Main.messageManner.username;
					infoWindow.nickName = Main.messageManner.nickname;
					infoWindow.Mail = Main.messageManner.mail;
					infoWindow.signInfo = Main.messageManner.signature;
					infoWindow.editable = false;
					infoWindow.addable = true;

					Stage messageStage = infoWindow.loadWindow();
					messageStage.show();
				} else {
					MessageWindow messageWindow = new MessageWindow();
					messageWindow.messageContext = new String("该用户不存在");
					Stage messageStage = messageWindow.loadWindow();
					messageStage.show();
				}
			});
			viewList.getChildren().add(node);
		}

		friendList.setContent(viewList);
	}

	@FXML
	void friend_onMousePressed(MouseEvent event) {
		System.out.println("friendshow");
		friendicon.setVisible(false);
		messageicon.setVisible(true);

		

		/////////////////////////////////////////
		updateFriendList(false);
		VBox viewList = new VBox();
		for (int i = 0; i < Main.friendlist.size(); i++) {
			FriendInfo friend = Main.friendlist.get(i);
			System.out.println("add friend " + friend.getNickname());
			HBox node = friend.toHBox();
			node.setOnMouseClicked(e -> {
				openWindow(e, friend.getUsername(), friend.getNickname(), friendname, title, messageArea, tools,
						inputArea);
			});
			viewList.getChildren().add(node);
		}
		friendList.setContent(viewList);
	}

	@FXML
	void friendShow_onMousePressed(MouseEvent event) {
		System.out.println("friendhide");
		friendicon.setVisible(true);
	}

	@FXML
	void message_onMousePressed(MouseEvent event) {
		System.out.println("messageshow");
		messageicon.setVisible(false);
		friendicon.setVisible(true);

		rebuildRecenet();
	}

	@FXML
	void messageShow_onMousePressed(MouseEvent event) {
		System.out.println("messagehide");
		messageicon.setVisible(true);
	}

	@FXML
	void backbutton_onMouseClicked(MouseEvent event) {
		title.setVisible(false);
		messageArea.setVisible(false);
		tools.setVisible(false);
		inputArea.setVisible(false);
	}

	@FXML
	void inputArea_onKeyReleased(KeyEvent event) {
		if (event.getCode() == KeyCode.ENTER) {
			System.out.println("on ENTER");
			String time = new Date().toString();
			Main.rcentMessage.addMessage(new Date().toString(), inputArea.getText(), Main.username, chatuser);
			addMessage(Main.username, inputArea.getText(), time, true);
			Main.messageManner.clear();
			Main.messageManner.setAction("send-message");
			Main.messageManner.setType("text");
			Main.messageManner.setReceiver(chatuser);
			Main.messageManner.setData2(time);
			Main.messageManner.sendMessage();
			if (Main.messageManner.status()) {
				MessageWindow messageWindow = new MessageWindow();
				messageWindow.messageContext = new String("消息发送失败，请重新尝试");
				Stage messageStage = messageWindow.loadWindow();
				messageStage.show();
			}
		}
	}

	@FXML
	void sendMessage_onMouseClicked(MouseEvent event) {

	}

	@FXML
	void sendFile_onMouseClicked(MouseEvent event) {
		// 创建文件选择器
		JFileChooser fileChooser = new JFileChooser();
		// 设置当前目录
		fileChooser.setCurrentDirectory(new File("."));
		fileChooser.addChoosableFileFilter(new FileFilter() {
			public boolean accept(File file) {
				return true;
			}

			public String getDescription() {
				return "所有文件(*.*)";
			}
		});
		//fileChooser.showDialog(null, null);
		int returnVal = fileChooser.showOpenDialog(fileChooser);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			System.out.println(fileChooser.getSelectedFile().getName());
			String filePath = fileChooser.getSelectedFile().getAbsolutePath(); // 这个就是你选择的文件夹的路径
			String fileName = fileChooser.getSelectedFile().getName();
			String time = new Date().toString();
			Main.messageManner.clear();
			Main.messageManner.setAction("send-message");
			Main.messageManner.setType("file");
			Main.messageManner.setReceiver(chatuser);
			Main.messageManner.setTime(time);
			Main.messageManner.setData(filePath);
			Main.messageManner.setFilename(fileName);
			Main.messageManner.sendMessage();
			
			addMessage(Main.username, "您已发送文件 \""+fileName+"\"", time, true);
			if (Main.messageManner.status()) {
				MessageWindow messageWindow = new MessageWindow();
				messageWindow.messageContext = new String("文件发送失败，请重新尝试");
				Stage messageStage = messageWindow.loadWindow();
				messageStage.show();
			}
		}
	}

	@FXML
	void sendPic_onMouedClicked(MouseEvent event) {

	}

	@FXML
	void sendVoice_onMouesClicked(MouseEvent event) {

	}

	@FXML
	void friendinfo_onMousePressed(MouseEvent event) {
		for (int i = 0; i != Main.friendlist.size(); i++) {
			System.out.println(Main.friendlist.get(i).getUsername() + "  " + chatuser);
			if (Main.friendlist.get(i).getUsername().equals(chatuser)) {
				InfoWindow infoWindow = new InfoWindow();
				infoWindow.userName = Main.friendlist.get(i).getUsername();
				infoWindow.nickName = Main.friendlist.get(i).getNickname();
				infoWindow.Mail = Main.friendlist.get(i).getMail();
				infoWindow.signInfo = Main.friendlist.get(i).getSignature();
				infoWindow.editable = false;
				infoWindow.addable = false;

				Stage messageStage = infoWindow.loadWindow();
				messageStage.show();
			}
		}
	}

	@FXML
	void deletefriend_onMousePressed(MouseEvent event) {
		Alert _alert = new Alert(Alert.AlertType.CONFIRMATION, "朋友，三思啊！", new ButtonType("取消", ButtonBar.ButtonData.NO),
				new ButtonType("确定", ButtonBar.ButtonData.YES));
		_alert.setTitle("删除");
		_alert.setHeaderText("您确定要删除该好友吗？");
		Optional<ButtonType> _buttonType = _alert.showAndWait();
		if (_buttonType.get().getButtonData().equals(ButtonBar.ButtonData.YES)) {
			Main.messageManner.clear();
			Main.messageManner.setAction("del-contact");
			Main.messageManner.setUsername(chatuser);
			Main.messageManner.sendMessage();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (Main.messageManner.status()) {
				MessageWindow messageWindow = new MessageWindow();
				messageWindow.messageContext = new String("删除好友操作成功");
				Stage messageStage = messageWindow.loadWindow();
				messageStage.show();
			} else {
				MessageWindow messageWindow = new MessageWindow();
				messageWindow.messageContext = Main.messageManner.description();
				Stage messageStage = messageWindow.loadWindow();
				messageStage.show();
			}
			// 更新好友列表
			updateFriendList(true);
			VBox viewList = new VBox();
			for (int i = 0; i < Main.friendlist.size(); i++) {
				FriendInfo friend = Main.friendlist.get(i);
				System.out.println("add friend " + friend.getNickname());
				HBox node = friend.toHBox();
				node.setOnMouseClicked(e -> {
					openWindow(e, friend.getUsername(), friend.getNickname(), friendname, title, messageArea, tools,
							inputArea);
				});
				viewList.getChildren().add(node);
			}
			friendList.setContent(viewList);
		} else {
			return;
		}
	}

	public HBox addiconHBox() {
		HBox hbox = new HBox(10);
		VBox vbox = new VBox(4);
		Text txtName;

		txtName = new Text("添加新的好友");

		avatar = new ImageView(getClass().getResource("../images/addicon.png").toString());
		avatar.setFitHeight(42);
		avatar.setFitWidth(42);

		txtName.setFont(Font.font("Microsoft YaHei", 22));
		txtName.setFill(Color.BLACK);

		vbox.getChildren().addAll(txtName);
		hbox.getChildren().addAll(avatar, vbox);
		hbox.setPadding(new Insets(3, 5, 3, 5));
		vbox.setAlignment(Pos.CENTER_LEFT);
		return hbox;
	}

	public void rebuildRecenet() {
		VBox viewList = new VBox();
		for (int i = 0; i != Main.friendlist.size(); i++) {
			String username = Main.friendlist.get(i).getUsername();
			String nickname = Main.friendlist.get(i).getNickname();
			HBox node = Main.rcentMessage.getHBox(username, nickname);
			node.setOnMouseClicked(e -> {
				openWindow(e, username, nickname, friendname, title, messageArea, tools, inputArea);
			});
			viewList.getChildren().add(node);
		}
		friendList.setContent(viewList);
	}

	private void addMessage(String sender, String context, String time, boolean reload) {
		// String messageTime = dateFormat.format(new Date(time));
		messageArea.setText(messageArea.getText() + sender + "\n    " + context + "\n\n");
		if (reload) {
			inputArea.setText("");
		}
	}

	public Stage loadWindow() {
		try {
			Parent windowParent = FXMLLoader.load(getClass().getResource("/application/MainLayout.fxml"));

			rebuildPane(windowParent);

			Scene windowScene = new Scene(windowParent);
			windowScene.setFill(null);
			windowStage = new Stage();
			windowStage.setTitle("密聊");
			windowStage.initStyle(StageStyle.TRANSPARENT);
			windowStage.setScene(windowScene);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return windowStage;
	}

	private void updateFriendList(boolean refresh) {
		long nowTime = new Date().getTime();
		if (refresh || nowTime - Main.friendUserDate > 120000) {
			Main.messageManner.clear();
			Main.messageManner.setAction("get-my-contacts");
			Main.messageManner.setGet("contacts");
			Main.messageManner.sendMessage();

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (Main.messageManner.contacts == null) {
				MessageWindow messageWindow = new MessageWindow();
				messageWindow.messageContext = new String("获取联系人列表失败");
				Stage messageStage = messageWindow.loadWindow();
				messageStage.show();
				return;
			}
			Main.friendlist.clear();

			System.out.println(Main.messageManner.contacts);
			if (Main.messageManner.contacts.equals("")) {
				Main.friendUser = new String[0];
			} else {
				Main.friendUser = Main.messageManner.contacts.split(",");
			}
			Main.friendUserDate = nowTime;

			for (int i = 0; i != Main.friendUser.length; i++) {
				Main.messageManner.clear();
				Main.messageManner.setAction("get-user-info");
				System.out.println("get user info - " + Main.friendUser[i]);
				Main.messageManner.setUsername(Main.friendUser[i]);
				Main.messageManner.sendMessage();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				FriendInfo newFriend = new FriendInfo();
				if (Main.messageManner.avatar == true) {
					newFriend.setAvatar_data(DefaultDefine.iconPath + Main.messageManner.username + ".jpg");
				} else {
					newFriend.setAvatar_data(DefaultDefine.iconPath+"default.jpg");
				}
				newFriend.setNickname(Main.messageManner.nickname);
				newFriend.setSignature(Main.messageManner.signature);
				newFriend.setUsername(Main.messageManner.username);
				Main.friendlist.add(newFriend);
			}
		}
	}

	private void rebuildPane(Parent windowParent) {
		ImageView avatar = (ImageView) windowParent.lookup("#avatar");
		ImageView friendicon = (ImageView) windowParent.lookup("#friendicon");
		HBox title = (HBox) windowParent.lookup("#title");
		TextArea messageArea = (TextArea) windowParent.lookup("#messageArea");
		HBox tools = (HBox) windowParent.lookup("#tools");
		TextArea inputArea = (TextArea) windowParent.lookup("#inputArea");
		ScrollPane friendList = (ScrollPane) windowParent.lookup("#friendList");
		Label friendname = (Label) windowParent.lookup("#friendname");

		updateFriendList(false);
		VBox viewList = new VBox();
		for (int i = 0; i < Main.friendlist.size(); i++) {
			FriendInfo friend = Main.friendlist.get(i);
			System.out.println("add friend " + friend.getNickname());
			HBox node = friend.toHBox();
			node.setOnMouseClicked(e -> {
				openWindow(e, friend.getUsername(), friend.getNickname(), friendname, title, messageArea, tools,
						inputArea);
			});
			viewList.getChildren().add(node);
		}
		friendList.setContent(viewList);

		friendicon.setVisible(false);
		title.setVisible(false);
		messageArea.setVisible(false);
		tools.setVisible(false);
		inputArea.setVisible(false);
	}

	private void openWindow(MouseEvent e, String username, String nickname, Label friendname, HBox title,
			TextArea messageArea, HBox tools, TextArea inputArea) {
		if (e.getClickCount() >= 1) {
			chatuser = username;
			friendname.setText(nickname);
			title.setVisible(true);
			messageArea.setVisible(true);
			tools.setVisible(true);
			inputArea.setVisible(true);
			messageArea.setText("");
			inputArea.setText("");
			String sender, receiver, context, time;
			for (int i = 0; i != Main.rcentMessage.msgList.size(); i++) {
				sender = Main.rcentMessage.msgList.get(i).msgSender;
				receiver = Main.rcentMessage.msgList.get(i).msgReceicer;
				context = Main.rcentMessage.msgList.get(i).msgContext;
				time = Main.rcentMessage.msgList.get(i).msgDate;
				if (sender.equals(chatuser) && receiver.equals(Main.username)) {
					addMessage(sender, context, time, false);
				}
				if (sender.equals(Main.username) && receiver.equals(chatuser)) {
					addMessage(Main.username, context, time, false);
				}
			}
		}
	}
}
