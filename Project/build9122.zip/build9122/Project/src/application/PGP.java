package application;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import org.bouncycastle.openpgp.PGPException;
import org.c02e.jpgpj.CompressionAlgorithm;
import org.c02e.jpgpj.EncryptionAlgorithm;
import org.c02e.jpgpj.Encryptor;
import org.c02e.jpgpj.HashingAlgorithm;
import org.c02e.jpgpj.Key;
import org.c02e.jpgpj.Subkey;

public class PGP {
	protected void doGet(String message){
			    /*// extract "message" request parameter to use as encrypted content
			    if (message == null || message.length() == 0)
			        message = "the medium is the message";

			    try {
			        // use Bob's public key for encryption
			        Encryptor encryptor = new Encryptor(
			            new Key(new File("path/to/my/keys/bob-pub.gpg"))
			        );
			        // use custom encryption, signing, and compression algorithms
			        encryptor.setEncryptionAlgorithm(EncryptionAlgorithm.CAST5);
			        encryptor.setSigningAlgorithm(HashingAlgorithm.SHA1);
			        encryptor.setCompressionAlgorithm(CompressionAlgorithm.ZLIB);
			        // output with ascii armor
			        encryptor.setAsciiArmored(true);

			        // manipulate Alice's secret key before supplying it to the encryptor
			        Key alice = new Key(new File("path/to/my/keys/alice-sec.gpg"));
			        for (Subkey subkey : alice.getSubkeys()) {
			            // don't use Alice's encryption subkey
			            if (subkey.isForEncryption())
			                subkey.setForEncryption(false);
			            // unlock Alice's signing subkey with a passphrase of "password123"
			            if (subkey.isForSigning())
			                subkey.setPassphrase("password123");
			        }
			        encryptor.getRing().getKeys().add(alice);

			        // encrypt the (ascii-armored) message to the response
			        /*File out;
			        try {
						encryptor.encrypt(
						    new ByteArrayInputStream(message.getBytes("UTF-8")),out
						);
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			    } catch (PGPException | IOException e) {
			        
			    }*/
			}

}
