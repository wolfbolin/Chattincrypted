package application;

import java.util.LinkedList;
import java.util.List;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
	protected static MessageManager messageManner;
	protected static List<FriendInfo> friendlist;
	protected static String[] friendUser;
	protected static long friendUserDate;
	protected static String username;
	protected static RecentMessage rcentMessage;

	@Override
	public void start(Stage primaryStage) {
		friendUserDate = 0;
		friendlist = new LinkedList<FriendInfo>();
		rcentMessage = new RecentMessage();
		messageManner = new MessageManager();
		messageManner.startThread();

		LoginWindow loginwindow = new LoginWindow();
		Stage loginStage = loginwindow.loadWindow();
		loginStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

}
