package util;

/**
 * Created by James Bamboo on 2016/12/27.
 */
public class Define {
    public static final int OK = 1;
    public static final int MAIN_RESIZE_WIDTH = 280;
    public static final int MAIN_MIN_WIDTH = 280;
    public static final int MAIN_MIN_HEIGHT = 550;
}
